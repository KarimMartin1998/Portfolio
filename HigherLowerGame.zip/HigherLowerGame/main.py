print("Welcome to the higher / lower game!")
from game_data import data
import random
from art import logo
from art import vs
score = 0
print(logo)

# Select one random choice from data
option1 = random.choice(data)
# Select another random choice from data
option2 = random.choice(data)
# Create functions to tell the users the name of the first / second random choice, description and country
def first_option():
  print(f"Compare A: {option1['name']}, a  {option1['description']}, from {option1['country']}")
def second_option():
  print(f"with B: {option2['name']}, a  {option2['description']}, from {option2['country']}")

# Call functions and vs logo from art.py
first_option()
print(vs)
second_option()

# Set game_over function to false
game_over = False
# Start loop until function turns to true, asking user to enter A or B:
while game_over != True:
  answer = input("Who has more followers? A or B: ").lower()
  # If A > B, add a point to score, set option2 to be option1 and choose another
  if answer == "a" and option1['follower_count'] > option2['follower_count']:
    print("Correct!")
    score += 1
    print(f"Current score: {score}")
    option2 = option1
    option1 = random.choice(data)
    first_option()
    print(vs)
    second_option()

  # If B > A, add a point to score, set option1 to be option2 and choose another
  elif answer == "b" and option2['follower_count'] > option1['follower_count']:
    print("Correct!")
    score += 1
    print(f"Current score: {score}")
    option1 = option2
    option2 = random.choice(data)
    first_option()
    print(vs)
    second_option()

  # If user gets the same choice for a question, run the same functionality as B being correct
  elif answer == "b" or answer == "a" and option2['follower_count'] == option1['follower_count']:
    print("Correct!")
    score += 1
    print(f"Current score: {score}")
    option1 = option2
    option2 = random.choice(data)
    first_option()
    print(vs)
    second_option()

  # If user mistypes or gets answer wrong, set game_over to true and print the final score
  else:
    game_over = True
    print("Incorrect!")
    print(f"Your final score was {score}")